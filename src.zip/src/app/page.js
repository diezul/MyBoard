export default function Home() {
  return (
    <div>
      <h1>Welcome to My Board App</h1>
      <a href="/login">Go to Login</a>
    </div>
  );
}
